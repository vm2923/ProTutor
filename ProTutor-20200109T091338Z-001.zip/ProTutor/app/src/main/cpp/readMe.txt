1. Models folder contain all the models for words, with following mapping.

"Apple_"=0
"Ball_"=1
"Candy_"=2
"Den_"=3
"Ear_"=4
"Fish_"=5
"Frog_"=6
"Home_"=7
"Igloo_"=8
"Jar_"=9

2. All the initial, which are needed to run the code are in folder files_for_run
