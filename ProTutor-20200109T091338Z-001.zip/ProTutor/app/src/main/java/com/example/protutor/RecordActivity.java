package com.example.protutor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.io.File;
import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class RecordActivity extends AppCompatActivity {

    private static final int SAMPLING_RATE_IN_HZ = 16000;

    private static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO;

    private static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;

    private static final int BUFFER_SIZE_FACTOR = 2;



    private static final int BUFFER_SIZE = AudioRecord.getMinBufferSize(SAMPLING_RATE_IN_HZ,
            CHANNEL_CONFIG, AUDIO_FORMAT) * BUFFER_SIZE_FACTOR;

    private final AtomicBoolean recordingInProgress = new AtomicBoolean(false);
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private AudioRecord recorder = null;
    private boolean permissionToRecordAccepted = false;

    private String [] permissions = {Manifest.permission.RECORD_AUDIO};
    private Thread recordingThread = null;
    private Thread stop_thread = null;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case REQUEST_RECORD_AUDIO_PERMISSION:
                permissionToRecordAccepted  = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                break;
        }
        //if (!permissionToRecordAccepted ) finish();

    }
    public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";


    /** Called when the user taps the Send button */
    public void sendMessage(View view) {
        Intent intent;
        intent = new Intent(this, ResultActivity.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        //String message = editText.getText().toString();
        //intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);

        // Capture the layout's TextView and set the string as its text
        TextView textView = findViewById(R.id.textView);
        textView.setText(message);
        ActivityCompat.requestPermissions(this, permissions, REQUEST_RECORD_AUDIO_PERMISSION);
        final Button i1 = findViewById(R.id.btnStart);
        i1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startRecording();
                i1.setEnabled(false);
                try {
                    stop_runnable();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

    }
    private void stop_runnable() throws InterruptedException {
        stop_thread = new Thread(new stop_thread_runnable(), "stop thread");
        stop_thread.sleep(3000);
        stopRecording();
    }

    private class stop_thread_runnable implements Runnable{
        @Override
        public void run() {

        }
    }
    private void startRecording() {
        recorder = new AudioRecord(MediaRecorder.AudioSource.DEFAULT, SAMPLING_RATE_IN_HZ,
                CHANNEL_CONFIG, AUDIO_FORMAT, BUFFER_SIZE);

        recorder.startRecording();

        recordingInProgress.set(true);

        recordingThread = new Thread(new RecordingRunnable(), "Recording Thread");
        recordingThread.start();
    }

    private void stopRecording() {
        if (null == recorder) {
            return;
        }

        recordingInProgress.set(false);

        recorder.stop();

        recorder.release();

        recorder = null;

        recordingThread = null;

        pcmtotxt();
        final Button i1 = findViewById(R.id.btnStart);
        i1.setEnabled(true);
    }

    private class RecordingRunnable implements Runnable {

        @Override
        public void run() {

            final File file = new File("/storage/emulated/0/Android/data/com.example.protutor/files/", "recording.pcm");
            final ByteBuffer buffer = ByteBuffer.allocateDirect(BUFFER_SIZE);
            //final File file1 =new File(getExternalCacheDir().getAbsolutePath(), "recording.txt");
            try (final FileOutputStream outStream = new FileOutputStream(file)) {

               /* if(!file1.exists()) {
                    file1.createNewFile();
                }
                FileWriter fileWritter = new FileWriter(file1.getName(),true);
                BufferedWriter bw = new BufferedWriter(fileWritter);*/
                while (recordingInProgress.get()) {
                    int result = recorder.read(buffer, BUFFER_SIZE);

                    //
                    if (result < 0) {
                        throw new RuntimeException("Reading of audio buffer failed: " +
                                getBufferReadFailureReason(result));
                    }
                    ByteBuffer b = ByteBuffer.wrap(buffer.array());
                    short[] shorts = new short[(buffer.array().length)/2];
                    ByteBuffer.wrap(buffer.array()).asShortBuffer().get(shorts);

                  /*
                    AtomicInteger i= new AtomicInteger();
                    while(i.get() <shorts.length)
                    {
                       bw.write(shorts[i.get()]);
                        i.getAndIncrement();
                    }
*/
                    outStream.write(buffer.array(), 0, BUFFER_SIZE);
                    b.clear();

                    buffer.clear();

                }


//bw.close();
            }
            catch (IOException e) {
                throw new RuntimeException("Writing of recorded audio failed", e);

            }
        }

        private String getBufferReadFailureReason(int errorCode) {
            switch (errorCode) {
                case AudioRecord.ERROR_INVALID_OPERATION:
                    return "ERROR_INVALID_OPERATION";
                case AudioRecord.ERROR_BAD_VALUE:
                    return "ERROR_BAD_VALUE";
                case AudioRecord.ERROR_DEAD_OBJECT:
                    return "ERROR_DEAD_OBJECT";
                case AudioRecord.ERROR:
                    return "ERROR";
                default:
                    return "Unknown (" + errorCode + ")";
            }
        }
    }
    public native void pcmtotxt();
}

