package com.example.protutor

import androidx.appcompat.app.AppCompatActivity

import android.os.Bundle
import android.content.Intent
import android.os.Parcel
import android.os.Parcelable
import android.provider.ContactsContract
import android.util.Patterns
import android.widget.ProgressBar
import com.google.firebase.auth.FirebaseAuth


import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_login.buttonSignin
import kotlinx.android.synthetic.main.activity_login.editTextEmail
import kotlinx.android.synthetic.main.activity_login.editTextPassword
import kotlinx.android.synthetic.main.activity_login.textViewSignUp
import java.lang.Exception


class LoginActivity() : AppCompatActivity(), Parcelable {

    private lateinit var mAuth: FirebaseAuth

    constructor(parcel: Parcel) : this() {

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        mAuth= FirebaseAuth.getInstance()
        buttonSignin.setOnClickListener {
            val email   = editTextEmail.text.toString().trim()
            val password= editTextPassword.text.toString().trim()
            if (email.isEmpty()){
                editTextEmail.error="Email Required"
                editTextEmail.requestFocus()
                return@setOnClickListener
            }
            if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                editTextEmail.error="Valid Email Required"
                editTextEmail.requestFocus()
                return@setOnClickListener
            }
            loginUser(email, password)
        }

        textViewSignUp.setOnClickListener {
            startActivity(Intent(this@LoginActivity, RegisterActivity::class.java) )
        }



    }

    private fun loginUser(email: String, password: String) {

        mAuth.signInWithEmailAndPassword(email,password)
                .addOnCompleteListener(this){task->
                    if (task.isSuccessful){
                        login()
                    }else{
                        task.exception?.message?.let {
                            toast(it)
                        }
                    }

                }
    }


    override fun onStart() {
        super.onStart()

        mAuth.currentUser?.let {
            login()
        }
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {

    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<LoginActivity> {
        override fun createFromParcel(parcel: Parcel): LoginActivity {
            return LoginActivity(parcel)
        }

        override fun newArray(size: Int): Array<LoginActivity?> {
            return arrayOfNulls(size)
        }
    }
}
