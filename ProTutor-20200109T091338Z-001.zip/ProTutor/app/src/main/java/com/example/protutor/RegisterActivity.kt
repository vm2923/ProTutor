package com.example.protutor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.util.Patterns
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.activity_register.buttonSignin
import kotlinx.android.synthetic.main.activity_register.editTextEmail
import kotlinx.android.synthetic.main.activity_register.editTextPassword
import kotlinx.android.synthetic.main.activity_register.textViewSignUp
import java.util.regex.Pattern

class RegisterActivity : AppCompatActivity() {
    private lateinit var  mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        mAuth = FirebaseAuth.getInstance()

        buttonSignin.setOnClickListener {
            val email   = editTextEmail.text.toString().trim()
            val password= editTextPassword.text.toString().trim()
            if (email.isEmpty()){
                editTextEmail.error="Email Required"
                editTextEmail.requestFocus()
                return@setOnClickListener
            }
            if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                editTextEmail.error="Valid Email Required"
                editTextEmail.requestFocus()
                return@setOnClickListener
            }

            registerUser(email, password)
        }

        textViewSignUp.setOnClickListener {
            startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))
        }

    }

    private fun registerUser(email: String, password: String) {


        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this){task->
                    if(task.isSuccessful){
                        //registration success
                        login()




                    }else{
                        task.exception?.message?.let {
                            toast(it)

                        }
                    }

                }

    }
    override fun onStart() {
        super.onStart()

        mAuth.currentUser?.let {
            login()
        }
    }
}
